import { useEffect, useState } from "react";
import logo from "../assets/logo.png";
import { useNavigate } from "react-router-dom";

function NavBar() {
  const [isLoggedIn,setIsLoggedIn] = useState();
  const navigate = useNavigate();

  useEffect(()=>{
    async function auth(){
      const res = await  fetch(`${import.meta.env.VITE_API_URL}check`,{
        credentials:"include",
      })
      const data = await res.json()
      if (data.success) {
        setIsLoggedIn(true)
      }else{
        setIsLoggedIn(false)
      }
    }auth()
  },[])

  function handleAuth(){
    navigate("/auth")
  }

  function handleProfile() {
    navigate("/profile");
  }

  function handleHome() {
    navigate("/");
  }
  return (
    <>
      <ul className="navbar">
        <li className="navbar-item-left">
          <img className="logo" src={logo} alt="logo" />
        </li>
        <li className="navbar-item-right" onClick={handleHome}>
          Home
        </li>
        <a
          className="plain-text"
          href="https://github.com/gem-plus"
          target="_blank"
        >
          <li className="navbar-item-right">Contact Us</li>
        </a>
        <li className="navbar-item-right" onClick={(isLoggedIn)?handleProfile:handleAuth}>
          {(isLoggedIn)? "Profile" : "Sign up"}
        </li>
      </ul>
    </>
  );
}

export default NavBar;
