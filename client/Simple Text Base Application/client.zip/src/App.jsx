import { Routes, Route } from "react-router-dom";
import Profile from "./pages/profile";
import Edit from "./pages/edit";
import Home from "./pages/home";
import Auth from "./pages/auth";

function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/auth" element={<Auth/>}/>
      <Route path="/profile" element={<Profile />} />
      <Route path="/edit" element={<Edit />} />
    </Routes>
  );
}

export default App;
